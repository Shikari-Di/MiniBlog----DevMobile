package com.example.simpleblog.database;

import android.provider.BaseColumns;

/**
 * Contrat de la base de données qui définit le schéma de la table des articles
 */
public final class ArticleContract {

    // Constructeur privé pour empêcher l'instanciation accidentelle
    private ArticleContract() {}

    /* Définition de la table des articles */
    public static class ArticleEntry implements BaseColumns {
        public static final String TABLE_NAME = "articles";
        public static final String COLUMN_TITLE = "title";
        public static final String COLUMN_CONTENT = "content";
        public static final String COLUMN_AUTHOR = "author";
        public static final String COLUMN_DATE = "date";

        // Requête SQL pour créer la table
        public static final String SQL_CREATE_TABLE =
                "CREATE TABLE " + TABLE_NAME + " (" +
                        _ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                        COLUMN_TITLE + " TEXT NOT NULL," +
                        COLUMN_CONTENT + " TEXT NOT NULL," +
                        COLUMN_AUTHOR + " TEXT NOT NULL," +
                        COLUMN_DATE + " TEXT NOT NULL)";

        // Requête SQL pour supprimer la table
        public static final String SQL_DELETE_TABLE =
                "DROP TABLE IF EXISTS " + TABLE_NAME;
    }
}