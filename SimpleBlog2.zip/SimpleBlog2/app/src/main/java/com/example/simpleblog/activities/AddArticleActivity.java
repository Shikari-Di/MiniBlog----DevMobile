package com.example.simpleblog.activities;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.simpleblog.R;
import com.example.simpleblog.database.ArticleDao;
import com.example.simpleblog.models.Article;
import com.google.android.material.textfield.TextInputEditText;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddArticleActivity extends AppCompatActivity {

    private TextInputEditText editTitle;
    private TextInputEditText editAuthor;
    private TextInputEditText editContent;
    private ArticleDao articleDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_article);

        // Initialiser la DAO
        articleDao = new ArticleDao(this);

        // Configurer les vues
        editTitle = findViewById(R.id.edit_title);
        editAuthor = findViewById(R.id.edit_author);
        editContent = findViewById(R.id.edit_content);

        Button buttonSave = findViewById(R.id.button_save);
        Button buttonCancel = findViewById(R.id.button_cancel);

        // Configurer les boutons
        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveArticle();
            }
        });

        buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    /**
     * Enregistre l'article dans la base de données
     */
    private void saveArticle() {
        // Récupérer les valeurs des champs
        String title = editTitle.getText() != null ? editTitle.getText().toString().trim() : "";
        String author = editAuthor.getText() != null ? editAuthor.getText().toString().trim() : "";
        String content = editContent.getText() != null ? editContent.getText().toString().trim() : "";

        // Vérifier que tous les champs sont remplis
        if (TextUtils.isEmpty(title) || TextUtils.isEmpty(author) || TextUtils.isEmpty(content)) {
            Toast.makeText(this, R.string.msg_fill_all_fields, Toast.LENGTH_SHORT).show();
            return;
        }

        // Obtenir la date actuelle
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        String currentDate = sdf.format(new Date());

        // Créer un nouvel article
        Article article = new Article(title, content, author, currentDate);

        // Enregistrer l'article dans la base de données
        long id = articleDao.insertArticle(article);

        if (id != -1) {
            // Succès
            Toast.makeText(this, R.string.msg_article_saved, Toast.LENGTH_SHORT).show();
            finish();
        } else {
            // Échec
            Toast.makeText(this, "Erreur lors de l'enregistrement", Toast.LENGTH_SHORT).show();
        }
    }
}