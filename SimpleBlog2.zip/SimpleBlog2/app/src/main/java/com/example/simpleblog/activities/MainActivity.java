package com.example.simpleblog.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.simpleblog.R;
import com.example.simpleblog.adapters.ArticleAdapter;
import com.example.simpleblog.database.ArticleDao;
import com.example.simpleblog.models.Article;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ArticleAdapter adapter;
    private TextView textNoArticles;
    private ArticleDao articleDao;
    private List<Article> articles;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialiser la DAO
        articleDao = new ArticleDao(this);

        // Initialiser la liste d'articles
        articles = new ArrayList<>();

        // Configurer les vues
        textNoArticles = findViewById(R.id.text_no_articles);
        recyclerView = findViewById(R.id.recycler_articles);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ArticleAdapter(this, articles);
        recyclerView.setAdapter(adapter);

        // Configurer le FAB pour ajouter un article
        FloatingActionButton fabAdd = findViewById(R.id.fab_add);
        fabAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AddArticleActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Mettre à jour la liste des articles à chaque fois que l'activité reprend le focus
        loadArticles();
    }

    /**
     * Charge les articles depuis la base de données et met à jour l'UI
     */
    private void loadArticles() {
        // Récupérer tous les articles
        List<Article> allArticles = articleDao.getAllArticles();

        // Mettre à jour l'adaptateur
        articles.clear();
        articles.addAll(allArticles);
        adapter.notifyDataSetChanged();

        // Afficher ou masquer le message "Aucun article"
        if (articles.isEmpty()) {
            textNoArticles.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        } else {
            textNoArticles.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
        }
    }
}