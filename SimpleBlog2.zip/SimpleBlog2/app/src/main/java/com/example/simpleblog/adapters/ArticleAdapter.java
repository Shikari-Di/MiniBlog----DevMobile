package com.example.simpleblog.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.simpleblog.R;
import com.example.simpleblog.activities.ArticleDetailActivity;
import com.example.simpleblog.models.Article;

import java.util.List;


public class ArticleAdapter extends RecyclerView.Adapter<ArticleAdapter.ArticleViewHolder> {

    private List<Article> articles;
    private Context context;

    public ArticleAdapter(Context context, List<Article> articles) {
        this.context = context;
        this.articles = articles;
    }

    @NonNull
    @Override
    public ArticleViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_article, parent, false);
        return new ArticleViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ArticleViewHolder holder, int position) {
        Article article = articles.get(position);

        holder.titleTextView.setText(article.getTitle());
        holder.authorTextView.setText(article.getAuthor());
        holder.dateTextView.setText(article.getDate());

        // Définir un court extrait du contenu (limité à 100 caractères)
        String contentPreview = article.getContent();
        if (contentPreview.length() > 100) {
            contentPreview = contentPreview.substring(0, 97) + "...";
        }
        holder.contentPreviewTextView.setText(contentPreview);

        // Configurer le clic sur l'élément
        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, ArticleDetailActivity.class);
                intent.putExtra("ARTICLE_ID", article.getId());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return articles.size();
    }

    /**
     * Met à jour les données de l'adaptateur
     * @param newArticles La nouvelle liste d'articles
     */
    public void updateData(List<Article> newArticles) {
        articles.clear();
        articles.addAll(newArticles);
        notifyDataSetChanged();
    }

    /**
     * ViewHolder pour les éléments de la liste des articles
     */
    static class ArticleViewHolder extends RecyclerView.ViewHolder {
        CardView cardView;
        TextView titleTextView;
        TextView authorTextView;
        TextView dateTextView;
        TextView contentPreviewTextView;

        public ArticleViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.card_view);
            titleTextView = itemView.findViewById(R.id.text_title);
            authorTextView = itemView.findViewById(R.id.text_author);
            dateTextView = itemView.findViewById(R.id.text_date);
            contentPreviewTextView = itemView.findViewById(R.id.text_content_preview);
        }
    }
}