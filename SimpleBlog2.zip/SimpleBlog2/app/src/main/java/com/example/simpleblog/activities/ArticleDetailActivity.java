package com.example.simpleblog.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.simpleblog.R;
import com.example.simpleblog.database.ArticleDao;
import com.example.simpleblog.models.Article;

public class ArticleDetailActivity extends AppCompatActivity {

    private ArticleDao articleDao;
    private long articleId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_article_detail);

        // Initialiser la DAO
        articleDao = new ArticleDao(this);

        // Récupérer l'ID de l'article depuis l'intent
        articleId = getIntent().getLongExtra("ARTICLE_ID", -1);

        if (articleId == -1) {
            // Erreur: aucun ID d'article n'est fourni
            Toast.makeText(this, "Erreur: article introuvable", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Configurer le bouton de retour
        Button buttonBack = findViewById(R.id.button_back);
        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // Charger et afficher l'article
        loadArticle();
    }

    /**
     * Charge les détails de l'article depuis la base de données et met à jour l'UI
     */
    private void loadArticle() {
        // Récupérer l'article par son ID
        Article article = articleDao.getArticleById(articleId);

        if (article == null) {
            // L'article n'a pas été trouvé
            Toast.makeText(this, "Erreur: article introuvable", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Référencer les vues
        TextView textTitle = findViewById(R.id.text_title);
        TextView textAuthor = findViewById(R.id.text_author);
        TextView textDate = findViewById(R.id.text_date);
        TextView textContent = findViewById(R.id.text_content);

        // Définir les valeurs
        textTitle.setText(article.getTitle());
        textAuthor.setText(article.getAuthor());
        textDate.setText(article.getDate());
        textContent.setText(article.getContent());
    }
}