package com.example.simpleblog.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.simpleblog.models.Article;

import java.util.ArrayList;
import java.util.List;

/**
 * Classe DAO (Data Access Object) pour les opérations CRUD sur les articles
 */
public class ArticleDao {
    private ArticleDbHelper dbHelper;

    public ArticleDao(Context context) {
        dbHelper = new ArticleDbHelper(context);
    }

    /**
     * Insère un nouvel article dans la base de données
     * @param article L'article à insérer
     * @return L'ID de la ligne insérée ou -1 si une erreur est survenue
     */
    public long insertArticle(Article article) {
        // Obtenir une base de données en écriture
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        // Créer un nouvel ensemble de valeurs pour insérer
        ContentValues values = new ContentValues();
        values.put(ArticleContract.ArticleEntry.COLUMN_TITLE, article.getTitle());
        values.put(ArticleContract.ArticleEntry.COLUMN_CONTENT, article.getContent());
        values.put(ArticleContract.ArticleEntry.COLUMN_AUTHOR, article.getAuthor());
        values.put(ArticleContract.ArticleEntry.COLUMN_DATE, article.getDate());

        // Insérer le nouvel enregistrement et retourner l'ID
        return db.insert(ArticleContract.ArticleEntry.TABLE_NAME, null, values);
    }

    /**
     * Récupère tous les articles de la base de données
     * @return Une liste de tous les articles
     */
    public List<Article> getAllArticles() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // Définir les colonnes à récupérer
        String[] projection = {
                ArticleContract.ArticleEntry._ID,
                ArticleContract.ArticleEntry.COLUMN_TITLE,
                ArticleContract.ArticleEntry.COLUMN_CONTENT,
                ArticleContract.ArticleEntry.COLUMN_AUTHOR,
                ArticleContract.ArticleEntry.COLUMN_DATE
        };

        // Trier par ID décroissant (les plus récents d'abord)
        String sortOrder = ArticleContract.ArticleEntry._ID + " DESC";

        Cursor cursor = db.query(
                ArticleContract.ArticleEntry.TABLE_NAME,
                projection,
                null,
                null,
                null,
                null,
                sortOrder
        );

        List<Article> articles = new ArrayList<>();

        while (cursor.moveToNext()) {
            Article article = new Article(
                    cursor.getLong(cursor.getColumnIndexOrThrow(ArticleContract.ArticleEntry._ID)),
                    cursor.getString(cursor.getColumnIndexOrThrow(ArticleContract.ArticleEntry.COLUMN_TITLE)),
                    cursor.getString(cursor.getColumnIndexOrThrow(ArticleContract.ArticleEntry.COLUMN_CONTENT)),
                    cursor.getString(cursor.getColumnIndexOrThrow(ArticleContract.ArticleEntry.COLUMN_AUTHOR)),
                    cursor.getString(cursor.getColumnIndexOrThrow(ArticleContract.ArticleEntry.COLUMN_DATE))
            );
            articles.add(article);
        }

        cursor.close();
        return articles;
    }

    /**
     * Récupère un article par son ID
     * @param id L'ID de l'article à récupérer
     * @return L'article trouvé, ou null si aucun article n'a été trouvé
     */
    public Article getArticleById(long id) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // Définir les colonnes à récupérer
        String[] projection = {
                ArticleContract.ArticleEntry._ID,
                ArticleContract.ArticleEntry.COLUMN_TITLE,
                ArticleContract.ArticleEntry.COLUMN_CONTENT,
                ArticleContract.ArticleEntry.COLUMN_AUTHOR,
                ArticleContract.ArticleEntry.COLUMN_DATE
        };

        // Filtrer par ID
        String selection = ArticleContract.ArticleEntry._ID + " = ?";
        String[] selectionArgs = { String.valueOf(id) };

        Cursor cursor = db.query(
                ArticleContract.ArticleEntry.TABLE_NAME,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        Article article = null;

        if (cursor.moveToFirst()) {
            article = new Article(
                    cursor.getLong(cursor.getColumnIndexOrThrow(ArticleContract.ArticleEntry._ID)),
                    cursor.getString(cursor.getColumnIndexOrThrow(ArticleContract.ArticleEntry.COLUMN_TITLE)),
                    cursor.getString(cursor.getColumnIndexOrThrow(ArticleContract.ArticleEntry.COLUMN_CONTENT)),
                    cursor.getString(cursor.getColumnIndexOrThrow(ArticleContract.ArticleEntry.COLUMN_AUTHOR)),
                    cursor.getString(cursor.getColumnIndexOrThrow(ArticleContract.ArticleEntry.COLUMN_DATE))
            );
        }

        cursor.close();
        return article;
    }

    /**
     * Supprime un article par son ID
     * @param id L'ID de l'article à supprimer
     * @return Le nombre de lignes affectées
     */
    public int deleteArticle(long id) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        // Définir la clause WHERE
        String selection = ArticleContract.ArticleEntry._ID + " = ?";
        String[] selectionArgs = { String.valueOf(id) };

        // Exécuter la requête de suppression
        return db.delete(ArticleContract.ArticleEntry.TABLE_NAME, selection, selectionArgs);
    }

    /**
     * Met à jour un article existant
     * @param article L'article à mettre à jour
     * @return Le nombre de lignes affectées
     */
    public int updateArticle(Article article) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        // Créer un nouvel ensemble de valeurs pour la mise à jour
        ContentValues values = new ContentValues();
        values.put(ArticleContract.ArticleEntry.COLUMN_TITLE, article.getTitle());
        values.put(ArticleContract.ArticleEntry.COLUMN_CONTENT, article.getContent());
        values.put(ArticleContract.ArticleEntry.COLUMN_AUTHOR, article.getAuthor());
        values.put(ArticleContract.ArticleEntry.COLUMN_DATE, article.getDate());

        // Définir la clause WHERE
        String selection = ArticleContract.ArticleEntry._ID + " = ?";
        String[] selectionArgs = { String.valueOf(article.getId()) };

        // Exécuter la requête de mise à jour
        return db.update(ArticleContract.ArticleEntry.TABLE_NAME, values, selection, selectionArgs);
    }

    /**
     * Ferme la base de données
     */
    public void close() {
        dbHelper.close();
    }
}