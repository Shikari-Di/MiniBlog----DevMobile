package com.example.simpleblog.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Helper de la base de données qui gère la création et la mise à jour de la base de données
 */
public class ArticleDbHelper extends SQLiteOpenHelper {

    // Si vous changez le schéma de la base de données, vous devez incrémenter la version
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "MiniBlog.db";

    public ArticleDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Création de la table des articles
        db.execSQL(ArticleContract.ArticleEntry.SQL_CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Cette méthode est appelée si le DATABASE_VERSION est incrémenté
        // Stratégie simple pour la mise à jour: supprimer et recréer la table
        db.execSQL(ArticleContract.ArticleEntry.SQL_DELETE_TABLE);
        onCreate(db);
    }

    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }
}